﻿

namespace Serein;

public class EverythingRenderer : Renderer
{
    public BlendState BlendState;
    public SamplerState SamplerState;
    public Effect Effect;
    public Camera Camera;

    public EverythingRenderer()
    {
        BlendState = BlendState.AlphaBlend;
        SamplerState = SamplerState.LinearClamp;
        Camera = new Camera();
    }

    public override void BeforeRender(Scene scene)
    {

    }

    public override void Render(Scene scene)
    {
        Draw.Batcher.PushMatrix(Camera.Matrix * Engine.ScreenMatrix);

        scene.Entities.Render();
        if (Engine.Commands.Open) 
            scene.Entities.DebugRender(Camera);

        Draw.Batcher.PopMatrix();
        // TODO: Do i some sort of Draw here since there once was a SpriteBatch.End()? Probably yea
    }

    public override void AfterRender(Scene scene)
    {

    }
}
